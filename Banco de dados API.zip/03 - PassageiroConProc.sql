Use AeroApi
Go

IF OBJECT_ID('PassageiroConProc') IS NULL
BEGIN
	EXEC('CREATE PROC PassageiroConProc AS SELECT 1')
END
GO
ALTER PROC PassageiroConProc @Id INT = NULL,@Nome NVARCHAR(50) = NULL,@Celular NVARCHAR(20) =NULL
/*
	EXEC PassageiroConProc @Id = 3
*/
AS
BEGIN
	IF @Id IS NULL AND (@Nome IS NULL OR LTRIM(RTRIM(@Nome)) = '') AND (@Celular IS NULL OR LTRIM(RTRIM(@Celular)) ='')
	BEGIN
		SELECT -1 codigo,
				'Sem dados para pesquisa' descricao
		RETURN
	END

	SELECT 0 codigo,
			'Consulta realizada com sucesso' descricao,
			Id,
			Idade,
			Nome,
			Celular
	FROM Passageiro
	WHERE (Id = @Id OR @Id IS NULL)
	  AND (Nome like '%' + @Nome+'%' OR @Nome IS NULL)
	  AND (Celular like '%' + @Celular + '%' OR @Celular IS NULL)
END
GO