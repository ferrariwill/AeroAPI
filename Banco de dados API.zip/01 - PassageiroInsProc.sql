Use AeroApi
Go

IF OBJECT_ID('PassageiroInsProc') IS NULL
BEGIN
	EXEC('CREATE PROC PassageiroInsProc AS SELECT 1')
END
GO

ALTER PROC PassageiroInsProc @Idade INT,@Nome NVARCHAR(50),@Celular NVARCHAR(20)
/*
	EXEC PassageiroInsProc @Idade = 10  ,@Nome = 'Teste',@Celular = '(15) 99999-9999'
*/
AS
BEGIN
	BEGIN TRY
		DECLARE @Id INT

		
		IF @Idade < 0
		BEGIN
			SELECT -1 codigo,
					'A idade tem que ser positiva' descricao
			RETURN
		END

		IF LTRIM(RTRIM(@Celular)) = '' OR @Celular IS NULL
		BEGIN
			SELECT -1 codigo,
					'Favor informar um telefone' descricao
			RETURN 
		END

		IF @Nome = '' OR @Nome IS NULL
		BEGIN
			SELECT -1 codigo,
					'Favor informar um Nome' descricao
			RETURN
		END

		BEGIN TRAN
		INSERT INTO Passageiro (Idade,Nome,Celular)
		VALUES(@Idade,@Nome,@Celular)
		COMMIT

		SET @Id = @@IDENTITY
		
		SELECT 0 codigo,
				'Passageiro incluido com sucesso' descricao,
				Id,
				Idade,
				Nome,
				Celular
		FROM Passageiro
		WHERE Id = @Id

	END TRY
	BEGIN CATCH
		ROLLBACK
		SELECT 1 codigo,
				ERROR_MESSAGE() descricao
	END CATCH
END
GO