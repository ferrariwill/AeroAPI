Use AeroApi
Go

IF OBJECT_ID('PassageiroDelProc') IS NULL
BEGIN
	EXEC('CREATE PROC PassageiroDelProc AS SELECT 1')
END
GO

ALTER PROC PassageiroDelProc @Id INT
/*
	EXEC PassageiroDelProc @Id = 1
*/
AS
BEGIN
	BEGIN TRY
		
		IF NOT EXISTS(SELECT 1 
						FROM Passageiro
						WHERE Id = @Id)
		BEGIN
			SELECT -1 codigo,
					'Passageiro n�o encontrado' descricao
			RETURN 
		END
		BEGIN TRAN
		DELETE Passageiro
		WHERE Id = @Id
		COMMIT

		SELECT 0 codigo,
				'Passageiro removido com sucesso' descricao
		RETURN

	END TRY
	BEGIN CATCH
		ROLLBACK
		SELECT 1 codigo,
				ERROR_MESSAGE() descricao
		RETURN
	END CATCH
END