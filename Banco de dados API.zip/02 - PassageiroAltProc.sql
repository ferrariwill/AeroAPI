Use AeroApi
Go

IF OBJECT_ID('PassageiroAltProc') IS NULL
BEGIN
	EXEC('CREATE PROC PassageiroAltProc AS SELECT 1')
END
GO

ALTER PROC PassageiroAltProc @Id INT,@Nome NVARCHAR(50) = NULL,@Idade INT = NULL,@Celular NVARCHAR(20) = NULL
/*
	EXEC PassageiroAltProc @Id = 3,@Nome ='teste 2'
*/
AS
BEGIN	
	BEGIN TRY
		

		IF NOT EXISTS(SELECT 1 
						FROM Passageiro
						WHERE Id = @Id)
		BEGIN
			SELECT -1 codigo,
					'Passageiro n�o encontrado' descricao
			RETURN 
		END

		IF @Idade < 0
		BEGIN
			SELECT -1 codigo,
					'A idade tem que ser positiva' descricao
			RETURN
		END

		IF LTRIM(RTRIM(@Celular)) = ''
		BEGIN
			SET @Celular = NULL
		END

		IF LTRIM(RTRIM(@Nome)) = ''
		BEGIN
			SET @Nome = NULL
		END

		IF	@Idade IS NULL AND 
			@Nome IS NULL AND 
			@Celular IS NULL
		BEGIN
			SELECT -1 codigo,
					'N�o h� dados para serem alterados' descricao
			RETURN
		END

		BEGIN TRAN
		UPDATE Passageiro SET Idade = ISNULL(@Idade,Idade),
								Nome = ISNULL(@Nome,Nome),
								Celular = ISNULL(@Celular,Celular)
		WHERE Id = @Id
		COMMIT

		SELECT 0 codigo,
				'Passageiro alterado com sucesso' descricao,
				Id,
				Idade,
				Nome,
				Celular
		FROM Passageiro
		WHERE Id = @Id

	END TRY
	BEGIN CATCH
		ROLLBACK
		SELECT 1 codigo,
				ERROR_MESSAGE() descricao
	END CATCH
END
GO
