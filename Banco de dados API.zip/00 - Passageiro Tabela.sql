USE [AeroApi]
GO

/****** Object:  Table [dbo].[Passageiro]    Script Date: 27/07/2020 16:07:51 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Passageiro]') AND type in (N'U'))
DROP TABLE [dbo].[Passageiro]
GO

/****** Object:  Table [dbo].[Passageiro]    Script Date: 27/07/2020 16:07:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Passageiro](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Nome] [nvarchar](50) NOT NULL,
	[Idade] [int] NOT NULL,
	[Celular] [nvarchar](20) NOT NULL
) ON [PRIMARY]
GO


